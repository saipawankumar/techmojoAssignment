package com.techmojo.ratelimiting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RateLimitingApplicationTests {

	@Test
	void contextLoads() {
	}

}
